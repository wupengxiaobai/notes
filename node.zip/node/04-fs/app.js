const fs = require('fs');

/* //  fs模块中遵循不带Sync结尾都是异步方法
fs.readFile("./1.txt", 'utf8', function (err, data) {
  //  没有错误则 err === null;有则 err 是一个错误对象, 我们可以根据情况进行不同操作
  if (err) throw err;
  console.log(data)
}) */

// function proIO(url) {
//   return new Promise((resolve, reject) => {
//     fs.readFile(url, 'utf8', function (err, data) {
//       if (err) reject(err);
//       resolve(data)
//     })
//   })
// }

// proIO('./1.txt')
//   .then(res => {
//     console.log(res)
//     return proIO('./2.txt');
//   })
//   .then(res => {
//     console.log(res)
//     return proIO('./3.txt')
//   })
//   .then(res => {
//     console.log(res)
//   })
//   .catch(err => {
//     console.log('有错误', err)
//   })

//  existsSync(path)  判断路径(文件)是否存在
// const path = './'
// console.log(fs.existsSync(path))

//  写文件
// fs.writeFile()

//  创建一个文件目录
// fs.mkdir('./wupeng', (err, data) => {
//   if (err) throw err;
//   console.log(data)
// })

// //  读文夹, 回调参数data是该文件夹下所有文件的数组
// fs.readdir('./fsdir', (err, data) => {
//   if (err) throw err
//   console.log(data)
// })

//  判断一个文件是否是文件
// const path = './node'
// fs.stat(path, (err, data) => {
//   console.log(data.isDirectory())
// })

const path = './node';

function getDir(callback) {
	fs.readdir(path, (err, data) => {
		var arr = [];
		(function iter(i) {
			if (i == data.length) {
				callback(arr);
				return;
			}
			const tem = path + '/' + data[i];
			fs.stat(tem, (err, stat) => {
				console.log(stat.isDirectory());
				stat.isDirectory() && arr.push(tem);
				iter(i + 1);
			});
		})(0);
	});
}

getDir(function(res) {
	console.log(res);
});

//  wupeng is a handsome man!
