const Readable = require('stream').Readable;
const fs = require('fs')
//  实例化
const rp = new Readable;
//  使用push往其中添加数据
rp.push("1");
rp.push("2");
rp.push("3");
rp.push("4");
rp.push("5");
//  push null 表示关闭接口
rp.push(null)

//  process全局对象的stdout输出
rp.pipe(process.stdout)

//  直接通过pipe(管道)方法通入可写流
rp.pipe(fs.createWriteStream('4.txt'))