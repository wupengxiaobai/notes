const fs = require('fs')


//  方式一: 使用事件监听方式读取数据并且写入数据
//  创建一个可读流
const read = fs.createReadStream('1.txt')
read.setEncoding('utf8');

var str = '';
read.on('data', (data) => {
  str += data;
});

read.on('end', () => {
  console.log('读取结束')
  fs.writeFile('./2.txt', str, (err) => {
    if (err) throw err;
  });
});

//  方式二: 如果是读写流共同操作, 可以直接使用 pipe() 写入到可写流中
//  创建一个可写流
const write = fs.createWriteStream('3.txt')
read.pipe(write)