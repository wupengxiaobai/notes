const fs = require('fs')

// var fres = fs.readFileSync('./1.txt', 'utf8')
// console.log(fres)

// fs.readFile('./1.txt', 'utf8', (err, data) => {
//   console.log(1) 
//    //  不管多少数据. 这里只触发1次
// })


// stream 流模块,  作用: 可以让我们的数据边读取边处理
//  fs本身继承了 stream
//  1. 创建可读流(静止)
const read = fs.createReadStream('1.txt')
//  2. 设置编码
read.setEncoding('utf8')
//  3. 从静止->流动
// read.resume()  // 该方式只能触发状态修改, 不能返回数据
//  该方法除了可以触发状态修改还可以监听到数据  
read.on('data', data => {
  //  这里出发了多次. 说明进行了流式读取数据, 读了多次
  console.log(1)
})
//  4.end方法 监听结束事件
read.on('end', () => {
  console.log('读取结束')
})

/***  监听的形式 
 * 小结: 
 *  stream 模块相比抽象, I/0操作 如 fs 都继承了该模块
 *  基础步骤(fs演示):
 *    1. 创建可读流   
 *          const read = fs.createReadStream('文件路径')
 *    2. 可以设置编码 
 *          read.setEncoding('utf8')
 *    3. 状态转换(静止->流动)  期间触发多次 console 说明是读取部分执行部分的操作, 也就是我们 流模块带来的好处
 *          read.resume()  // 该方式只能触发状态修改, 不能返回数据
 *          read.pipe() //  管道, 如果直接复制数据情况可以直接使用该方法, 参数即目标位置
 *          read.on('data', data => {console.log(1)})
 *    4. 监听读取完毕
 *          read.on('end', ()=>{console.log(读取结束)})
 */


