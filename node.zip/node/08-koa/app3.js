const koa = require('koa')

const app = new koa

app.use(async (ctx, next) => {
  // console.log(ctx)
  /* ctx.status = 201
  ctx.type = 'text/html'
  ctx.body = '<h1>wupeng is a handsome man</h1>' */

})

app.listen('9990', () => {
  console.log('9990 running... because wupeng is a handsome man!')
})



/*
{ request:
  { method: 'GET',
    url: '/',
    header:
     { host: 'localhost:9990',
       connection: 'keep-alive',
       'cache-control': 'max-age=0',
       'upgrade-insecure-requests': '1',
       'user-agent':
        'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36',        accept:
        'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*\/*;q=0.8',
       'accept-encoding': 'gzip, deflate, br',
       'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8' } },
 response: { status: 404, message: 'Not Found', header: {} },
 app: { subdomainOffset: 2, proxy: false, env: 'development' },
 originalUrl: '/',
 req: '<original node req>',
 res: '<original node res>',
 socket: '<original node socket>' }
 */

/**************
 *  我们可以看出中间件的执行上下文 ctx 中
 *   req 和 res 就是原生node中createServer回调中的 request和response对象
 * 
 *   request 和 response 是 koa 对原始node的 req/res 进行的封装后的 对象
 * 推荐使用 封装后的 request 和 response
 * 
 * ctx.body  用于响应的方法
 *    * 就是我们返回给前端的数据
 *    * 可以调用多次 
 *    * 可以不用 end 结束
 *    * 可以直接返回非字符串和buffer数据(如果写一个 json,底层会处理返回一个json字符串)
 * 
 * ctx.request.url === ctx.url
 * ctx.method === ctx.request.method
 * ctx.queryString === ctx.request.queryString
 * ....
 * ctx.url 请求地址 + query信息
 * ctx.path 请求地址
 * ctx.query query参数对象
 * ctx.type mini类型
 * ctx.status 状态码
 * 
 * ctx.state 用于不同中间件传递数据
 */