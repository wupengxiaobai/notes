const koa = require('koa')

const app = new koa
/*
app.use(async (ctx, next) => {
  console.log('中间件1接收请求')
  await next()
  console.log('中间件1响应数据')
})

app.use(async (ctx, next) => {
  console.log('中间件2请求数据')
  await next()
  console.log('中间件2响应数据')
})

app.use(async (ctx, next) => {
  console.log('中间件3请求数据')
  await next()
  console.log('中间件3响应数据')
})

app.listen('9990', () => {
  console.log('9990 running... because wupeng is a handsome man!')
})
/*
/*  如果交出控制权, 则控制权会在下一层中间件函数执行完成就会自动回归
  中间件1接收请求
  中间件2请求数据
  中间件3请求数据
  中间件3响应数据
  中间件2响应数据
  中间件1响应数据
*/


app.use(async (ctx, next) => {
  console.log('中间件1接收请求')
  console.log('中间件1响应数据')
})

app.use(async (ctx, next) => {
  console.log('中间件2请求数据')
  await next()
  console.log('中间件2响应数据')
})

app.use(async (ctx, next) => {
  console.log('中间件3请求数据')
  await next()
  console.log('中间件3响应数据')
})

app.listen('9990', () => {
  console.log('9990 running... because wupeng is a handsome man!')
})

/* 如果没有交出控制权, 则不会执行下步的中间件函数
中间件1接收请求
中间件1响应数据
*/