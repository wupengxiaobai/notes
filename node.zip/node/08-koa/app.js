const koa = require('koa')

const app = new koa

//  我们把处理请求的函数都叫做中间件
//  koa 接收中间件, 通过 use 方法注册到 koa 实例中
app.use(async (ctx, next) => {
  //  ctx   当前请求的上下文对象
  //  next  可以理解为下一个中间件  通过 next() 可以将控制权交给下一个中间件,  
  //    下一个中间件如果执行完毕, 默认会把权限交还给当前的执行上下文
})

app.use(async (ctx, next) => {})

app.use(async (ctx, next) => {})
//  中间件数组 [async1, async2, async....]


app.listen('9990', () => {
  console.log('9990 running... because wupeng is a handsome man!')
})