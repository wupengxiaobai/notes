const EventEmitter = require('events').EventEmitter
const myEmitter = new EventEmitter
const fn = () => {
  console.log('一个异步执行函数');
}
//  on 监听 someEvent 和 someEvent2 事件
myEmitter.on('someEvent', fn)
myEmitter.on('someEvent2', (op) => {
  console.log('另一个异步执行函数', op);
})
setTimeout(() => {
  //  emit 执行 someEvent 和 someEvent2 事件, 除第一个参数外其他参数传递给回调的参数
  myEmitter.emit('someEvent')
  myEmitter.emit('someEvent2', 2)
}, 2000)
//  once 一次事件
//  newListener 事件, 被监听的事件没有被执行时, 创建其它监听事件则会执行该监听事件
//  removeListener 事件, 被监听事件被解除监听触发该事件
//  setMaxListener 设置某个被监听的事件最多绑定多少个回调, 超出则报提示

//  继承距离
function Fn(name) {
  this.name = name
}
Fn.prototype.__proto__ = EventEmitter.prototype
let xb = new Fn('小白')
xb.on('oneEvent', function () {
  console.log(this.name)
})

setTimeout(()=>{
  xb.emit('oneEvent');
},1000)