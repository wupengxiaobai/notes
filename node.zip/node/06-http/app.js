const http = require('http')

const server = http.createServer((req, res) => {
  

  //  设置状态码
  res.writeHead(200, {
    "Content-Type": "text/plain; charset=utf-8"
  })
  // res.setHeader('Content-Type','text/plain; charset=utf-8')
  res.write('吴鹏是一位英俊的男人\n')
  res.write(req.url + '\n')
  res.write(JSON.stringify(req.headers) + '\n')
  //  end只调用一次
  res.end('\n大兄弟就爱讲实话~')
})


server.listen('9990', '127.0.0.1', function () {
  console.log('running in 9990');
})