const http = require('http')
const fs = request('fs')

const server = http.createServer((req, res) => {

  if (req.method == 'GET') {
    res.writeHead(200, {
      "Content-Type": "text/html; charset=utf-8"
    })
    switch (req.url) {
      case '/index':
        const read = fs.createF
        break;
      case '/user':
        res.write('<h1>user</h1>')
        break;
      case '/home':
        res.write('<h1>home</h1>')
        break;
      case '/other':
        res.write('<h1>other</h1>')
        break;
      default:
        res.write('<h1>404</h1>')
    }
  }
  res.end('');
})


server.listen('9990', '127.0.0.1', function () {
  console.log('running in 9990');
})