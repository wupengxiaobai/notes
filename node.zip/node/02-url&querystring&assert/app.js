// const {
//   URL,
//   resolve
// } = require('url')

// const myUrl = new URL('http://localhost:8080?user=xiaobai&pass=1234')
// // console.log(myUrl)
// console.log(resolve('/user/local', 'node'))
// console.log(resolve('/user/local/', 'node'))
// console.log(resolve('/user/local/', '../node'))
// console.log(resolve('/user/local/', '/node'))


// const querystring = require('querystring')
// const qs = querystring.parse('w=%D6%D0%CE%C4&foo=bar');
// console.log(querystring.unescape(qs.w))
// console.log(qs)
// const qs2 = querystring.stringify(qs, ';',":");
// console.log(qs2)


const assert = require('assert');

assert.strictEqual(1, 1, '如果不严格相等, 则抛出该错误信息')

try{
  assert.notStrictEqual({a:1}, {a:1}, '如果不严格相等, 则抛出该错误信息')
  // assert.strictEqual({a:1}, {a:1}, '如果不严格相等, 则抛出该错误信息')
}catch(e){
  console.log('不完全相等对象')
}