const crypto = require('crypto')
/**
 * 
 * @param {String} password 用户密码
 * @param {String} KEY 附加密钥
 */

module.exports = function (password, KEY = "wupeng is a handsome man") {
  const hmac = crypto.createHmac('sha256', KEY)
  hmac.update(password)
  const passwordHex = hmac.digest("hex")
  return passwordHex
}