// crypto 加密模块
const crypto = require('crypto')
const KEY = 'xioabaidashuaibi'
//  获取所有hash加密方式
// console.log(crypto.getHashes())
//  1. 创建加密方式
const md5 = crypto.createHash('md5')
//  2. 使用该方式进行加密
md5.update(KEY)
//  3. 加密输出数据类型, 只能 digest 一次
const passStr = md5.digest("hex") // 默认输出二进制数据, 可以指定输出数据类型
//  打印加密数据
console.log(passStr)


//  引入模块加密输出
const jm = require('./cryptoModel')
console.log(jm('wupengXIAOBAI1234'))