//  app_.js 主要用于请求服务器, 该服务器是开放的,解决浏览器阻断问题
const http = require('http')

const options = {
  host: "localhost",
  port: 9000,
  method: 'get',
  path: '/'
}

const fn = reponse => {
  let data = {}
  const requestObj = http.request(options, res => {
    res.setEncoding('utf8')
    res.on('data', chunk => {
      data = chunk
    })
    res.on('end', () => {
      reponse.end(data)
    })
  })
  //  监听错误信息
  requestObj.on('error', err => {
    console.log(err)
  })
  requestObj.write('')
  requestObj.end()
}

const server = http.createServer((req, res) => {
  //  CORS 跨域
  res.setHeader('Access-Control-Allow-Origin', '*')
  fn(res)
}).listen('9001',function(){
  console.log('running in 9001')
})