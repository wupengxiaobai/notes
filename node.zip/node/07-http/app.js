const http = require('http')

http.createServer((req, res) => {
  const data = {
    title: "吴鹏大帅比",
    desc: "您真爱讲实话"
  }
  res.write(JSON.stringify(data))
  res.end('')

}).listen('9000', function () {
  console.log('running in 9000')
})