const Koa = require('koa')
const request = require('superagent')
const cheerio = require('cheerio')
const path = require('path')

const app = new Koa
/* {
  imgUrl: ,
  title: ,
  author: ,
  desc:,
  star: ,
  type:,
}*/

//  相关配置和地址
const config = {
  page: 1,
  kind: 100,
  // bList: `https://read.douban.com/category/?page=${this.page}&kind=${this.kind}`,
  // dLink: 'https://read.douban.com/ebook/'
  linkAddress: `https://book.douban.com/`,
  bookDetail: `https://book.douban.com/subject/30366534/?icn=index-topchart-subject`
}

const regRule = {
  _trim_n: /\n|\ /g, //  空格和换行
  _num: /^\d{0,}\d$/g
}

let arr = []

request
  .post(config.linkAddress)
  .end((err, res) => {
    const data = res.text
    const $ = cheerio.load(data)
    //  分析结构
    $('.popular-books .list-summary li').each((i, v) => {
      const $v = $(v)
      const obj = {
        imgUrl: $v.find('.cover img').prop('src'),
        id: $v.find('.cover a').prop('href').match(regRule._num),
        title: $v.find('.info .title').text().replace(regRule._trim_n, ''),
        author: $v.find('.info .author').text().replace(regRule._trim_n, ''),
        desc: $v.find('.info .reviews').text().replace(regRule._trim_n, ''),
        star: $v.find('.info .average-rating').text().replace(regRule._trim_n, '')
      }
      arr.push(obj)
    })
    console.log(arr)
  })



// app.use(async (ctx, next) => {

// })


// app.listen('9990', () => {
//   console.log('9990 running... because wupeng is a handsome man!')
// })


/**************
 *  request 
 *  superagent 
 * 
 *  cheerio 解析字符串 html
 * 
 * 
 */