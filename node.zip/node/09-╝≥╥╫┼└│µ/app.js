const Koa = require('koa')
const request = require('superagent')
const cheerio = require('cheerio')
const path = require('path')

const app = new Koa
/* 
{
  imgUrl: ,
  title: ,
  author: ,
  desc:,
  star: ,
  type:,
}
*/

//  相关配置和地址
const config = {
  page: 1,
  kind: 100,
  bList: `https://read.douban.com/category/?page=${this.page}&kind=${this.kind}`,
  dLink: 'https://read.douban.com/ebook/'
}


let arr = []

request
  .post(config.bList)
  .end((err, res) => {
    const data = res.text

    console.log(data)
    
    const $ = cheerio.load(data)
    //  分析结构
    // console.log($('.works-item'))
    $('.works-item').each((i, v) => {
      const $v = $(v)
      const obj = {
        imgUrl: $v.find('.inner .pic img').prop('src'),
        id: $v.find('.inner .pic').prop('href'),
        title: $v.find('.info .title a').prop('title'),
        author: $v.find('.info .author a:nth-of-type(1)').prop('href'),
        yi: $v.find('.info .author a:nth-of-type(2)').prop('href'),
        desc: $v.find('.info .intro').text(),
        star: $v.find('.extra-info .score').text(),
        type: $v.find('.extra-info .kind-link').text()
      }
      arr.push(obj)
    })
  })



// app.use(async (ctx, next) => {

// })


// app.listen('9990', () => {
//   console.log('9990 running... because wupeng is a handsome man!')
// })


/**************
 *  request 
 *  superagent 
 * 
 *  cheerio 解析字符串 html
 * 
 * 
 */